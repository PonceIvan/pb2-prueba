package ar.edu.unlam.pb2.eva03;

public interface Terrestre {
	Double getVelocidad();
}
