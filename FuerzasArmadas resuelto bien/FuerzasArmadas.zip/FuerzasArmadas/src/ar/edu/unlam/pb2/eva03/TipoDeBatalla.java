package ar.edu.unlam.pb2.eva03;

public enum TipoDeBatalla {
	TERRESTRE, AEREA, ACUATICA

}
